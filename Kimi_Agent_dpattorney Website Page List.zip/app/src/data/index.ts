export * from './teamData';
export * from './practiceData';
export * from './insightsData';
export * from './careersData';
export * from './aboutData';
export * from './contactData';
export * from './legalData';
